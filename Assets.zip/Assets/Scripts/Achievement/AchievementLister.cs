using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Tato t��da slou�� k vyps�n� n�zv� a popis� v�ech achievement� ve h�e do textov�ho pole.
/// </summary>
public class AchievementLister : MonoBehaviour
{
    // Seznam v�ech achievement� v h�e
    public List<Achievement> achievements;

    // Textov� pole pro zobrazen� informac� o achievementech
    public Text achievementText;

    /// <summary>
    /// Metoda Start projde seznam achievement� a vyp�e jejich n�zvy a popisy do textov�ho pole.
    /// </summary>
    void Start()
    {
        // T��da StringBuilder pro postupn� p�id�v�n� textu
        StringBuilder sb = new StringBuilder();

        // Projdi seznam achievement� a vypi� jejich n�zvy a popisy v textov�m poli
        foreach (Achievement achievement in achievements)
        {
            sb.AppendLine("Achievement: " + achievement.name + ", Popis: " + achievement.description);
        }

        // Nastav textov� pole na v�sledn� �et�zec
        achievementText.text = "V�echny Achievementy: \n" + sb.ToString();
    }
}