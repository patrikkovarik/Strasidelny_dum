using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Spravuje odemyk�n� achievement� a zobrazov�n� informac� o odem�en�ch achievementech.
/// *K�d je nedokon�en�
/// </summary>
public class AchievementManager : MonoBehaviour
{
    // Seznam achievement�, kter� mohou b�t odem�eny
    public List<Achievement> achievements;
    // Textov� objekt pro zobrazen� informac� o odem�en�m achievementu
    public Text achievementText;

    // vol� metodu EarnAchievement
    private void Update()
    {
        EarnAchievement("Dohraj hru");
    }

    /// <summary>
    /// Odemkne achievement podle n�zvu a zobraz� informaci o odem�en� v textov�m objektu.
    /// </summary>
    /// <param name="achievementName">N�zev achievementu</param>
    public void EarnAchievement(string achievementName)
    {
        // Najde achievement podle n�zvu v seznamu achievements
        Achievement achievementToEarn = achievements.Find(achievement => achievement.name == achievementName);

        // Pokud byl achievement nalezen, odemkne ho a zobraz� informaci o odem�en� v textov�m objektu
        if (achievementToEarn != null)
        {
            achievementToEarn.Earn();
            achievementText.text = "Achievement unlocked: " + achievementName;
        }
        // Pokud achievement nebyl nalezen, vyp�e upozorn�n� do konzole
        else
        {
            Debug.LogWarning("Achievement '" + achievementName + "' nebyl nalezen!");
        }
    }

    /// <summary>
    /// P�echod na hlavn� menu.
    /// </summary>
    public void MainMenuButton()
    {
        SceneManager.LoadScene("MainMenu");
    }
}