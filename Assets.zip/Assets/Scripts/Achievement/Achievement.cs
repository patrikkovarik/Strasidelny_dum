using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// T��da reprezentuj�c� jednotliv� achievement
/// </summary>
public class Achievement : MonoBehaviour
{
    // N�zev achievementu
    public string names;

    // Popis achievementu
    public string description;

    // Byl ji� achievement z�sk�n
    private bool isEarned = false;

    /// <summary>
    /// Metoda pro z�sk�n� achievementu
    /// </summary>
    public void Earn()
    {
        if (!isEarned)
        {
            isEarned = true;

            Debug.Log("Z�skal jsi achievement: " + names + "\n" + description);
        }
    }
}