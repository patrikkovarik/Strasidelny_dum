using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// T��da MainMenu slou�� k ovl�d�n� hlavn�ho menu hry.
/// </summary>

public class MainMenu : MonoBehaviour
{
    /// <summary>
    /// Metoda pro spu�t�n� hry.
    /// </summary>
    public void PlayGame()
    {
        SceneManager.LoadScene("SampleScene"); // na�te sc�nu s n�zvem "Level1"
    }
    /// <summary>
    /// Metoda pro zobrazen� menu s mo�nostmi.
    /// </summary>
    public void Options()
    {
        SceneManager.LoadScene("Options"); // na�te sc�nu s n�zvem "Options"
    }

    /// <summary>
    /// Metoda pro zobrazen� menu s achievementy.
    /// </summary>
    public void Achievement()
    {
        SceneManager.LoadScene("Achievement"); // na�te sc�nu s n�zvem "Achievement"
    }

    /// <summary>
    /// Metoda pro ukon�en� hry.
    /// </summary>
    public void QuitGame()
    {
        Debug.Log("Quitting game..."); // vyp�e zpr�vu v konzoli
        Application.Quit(); // ukon�� aplikaci
    }
}