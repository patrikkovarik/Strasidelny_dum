using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// T��da reprezentuj�c� menu s nastaven�m hry. K�d neni dokon�en�.
/// </summary>

public class OptionsMenu : MonoBehaviour
{
    public Toggle fullscreenToggle; // Reference na p�ep�na� cel� obrazovky
    public Dropdown resolutionDropdown; // Reference na rozbalovac� seznam s rozli�en�m
    public Slider volumeSlider; // Reference na posuvn�k hlasitosti
    public Button applyButton; // Reference na tla��tko aplikovat
    public Button backButton; // Reference na tla��tko zp�t
    private Resolution[] resolutions;  // Pole pro uchov�n� dostupn�ch rozli�en�
    int currentResolutionIndex;

    private void Start()
    {
        // Z�sk�n� dostupn�ch rozli�en� a jejich p�id�n� do rozbalovac�ho seznamu
        resolutions = Screen.resolutions;

        List<string> options = new List<string>();
        currentResolutionIndex = 0;

        for (int i = 0; i < resolutions.Length; i++)
        {
            string option = resolutions[i].width + " x " + resolutions[i].height;
            options.Add(option);

            // Pokud je nalezeno aktu�ln� rozli�en�, nastav� se jeho index
            if (resolutions[i].width == Screen.currentResolution.width &&
                resolutions[i].height == Screen.currentResolution.height)
            {
                currentResolutionIndex = i;
            }

            Screen.fullScreen = true; // Nastaven� cel� obrazovky
            Resolution resolution = Screen.currentResolution; // Z�sk�n� aktu�ln�ho rozli�en�
            Screen.SetResolution(resolution.width, resolution.height, true); // Nastaven� na aktu�ln� rozli�en� v re�imu cel� obrazovky

        }

        resolutionDropdown.AddOptions(options);
        resolutionDropdown.value = currentResolutionIndex;
        resolutionDropdown.RefreshShownValue();

        // Nastaven� po��te�n�ch hodnot pro nastaven�
        fullscreenToggle.isOn = Screen.fullScreen;
        volumeSlider.value = AudioListener.volume;

        // P�i�azen� metody k tla��tku zp�t
        backButton.onClick.AddListener(GoBackToMenu);

        resolutionDropdown.onValueChanged.AddListener(delegate
        {
            DropdownValueChange(resolutionDropdown);
        });
    }

    public void SetFullscreen(bool isFullscreen)
    {
        Screen.fullScreen = isFullscreen;
    }

    public void SetResolution()
    {
        Resolution resolution = resolutions[currentResolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
        Debug.Log("Vybr�no rozli�en�: " + resolution.width + " x " + resolution.height);
    }

    public void SetVolume(float volume)
    {
        AudioListener.volume = volume;
    }

    void DropdownValueChange(Dropdown dropdown)
    {
        currentResolutionIndex = dropdown.value;
    }

    public void ApplyChanges()
    {
        Debug.Log(currentResolutionIndex);
        // Ulo�en� nastaven� do souboru nebo u�ivatelsk�ch preferenc�
        PlayerPrefs.SetInt("fullscreen", Screen.fullScreen ? 1 : 0);
        PlayerPrefs.SetFloat("volume", AudioListener.volume);
        PlayerPrefs.SetInt("resolutionIndex", resolutionDropdown.value);
        PlayerPrefs.Save();
        Debug.Log("Ulo�eno");
    }

    public void GoBackToMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
